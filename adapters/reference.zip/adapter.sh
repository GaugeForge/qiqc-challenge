#!/bin/sh
# Contract example. The demo maps this exact package hash to Harbor built-in Codex.
# Entrypoints from uploaded packages are NEVER executed on the VPS.
exec codex exec --skip-git-repo-check --model "$QIQC_MODEL" "$(cat "$QIQC_TASK_INPUT")"
