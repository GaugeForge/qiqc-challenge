# Codex reference harness

This exact package selects the organizer-owned Harbor Codex adapter for a local mock task.
Modified packages require manual review and can only use simulated execution in this demo.
Production ABI, E2B isolation and Hy4 compatibility still require validation.
